package cm;

public enum CarParkKind {
    STAFF, STUDENT, MANAGEMENT, VISITOR
}
