package cm;

public enum CarParkStatus {
    OPEN, CLOSED, FULL
}

